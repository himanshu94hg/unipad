function myFunction1() {
   document.getElementById("mylist1").classList.add("PoolNav_itemSelected__25MGl");
   document.getElementById("mylist").classList.remove("PoolNav_itemSelected__25MGl");
   document.getElementById("mylist2").classList.remove("PoolNav_itemSelected__25MGl");
   
   
}

function myFunction() {
   document.getElementById("mylist").classList.add("PoolNav_itemSelected__25MGl");
   document.getElementById("mylist1").classList.remove("PoolNav_itemSelected__25MGl");
   document.getElementById("mylist2").classList.remove("PoolNav_itemSelected__25MGl");
   
   
}


function myFunction2() {
   document.getElementById("mylist2").classList.add("PoolNav_itemSelected__25MGl");
   document.getElementById("mylist").classList.remove("PoolNav_itemSelected__25MGl");
   document.getElementById("mylist1").classList.remove("PoolNav_itemSelected__25MGl");
   
   
}



